﻿using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace BlazorApp_Practices.Data
{
    public class StudentRecordService
    {
        public async Task<List<StudentRecordModel>> GetAllStudentsAsync()
        {
            SqlConnection con = new SqlConnection("Data Source=localhost;Initial Catalog=Students_DB;User Id=sa;password=<password>; Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from tbl_Students order by id", con);
            SqlDataReader r =  cmd.ExecuteReader();
            StudentRecordModel st = new StudentRecordModel();
            List<StudentRecordModel> SR = new List<StudentRecordModel>();

            if (r.HasRows)
            {
                while (r.Read())
                {
                    st = new StudentRecordModel();
                    st.Id = (int)r["Id"];
                    st.Name = r["Name"].ToString();
                    st.Age = (int)r["age"];
                    st.Address = r["Address"].ToString();
                    SR.Add(st);
                }
                return SR;
            }
            con.Close();
            return null;
        }

        public async Task<int> SaveStudentRecordAsync(StudentRecordModel s)
        {
            SqlConnection con = new SqlConnection("Data Source=localhost;Initial Catalog=Students_DB;User Id=sa;password=<password>; Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into tbl_Students ([Name], [Age], [Address])values(@name, @age, @address)", con);
            cmd.Parameters.AddWithValue("@name", s.Name);
             cmd.Parameters.AddWithValue("@age", s.Age);
            cmd.Parameters.AddWithValue("@address", s.Address);
          int b=  await cmd.ExecuteNonQueryAsync();
          
            con.Close();
            return b;
        }

        public async Task<int>DeleteStudentRecordAsync(StudentRecordModel s)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=localhost;Initial Catalog=Students_DB;User Id=sa;password=<password>; Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("delete from tbl_Students where id=@id", con);
                cmd.Parameters.AddWithValue("@id", s.Id);
                await cmd.ExecuteNonQueryAsync();
                con.Close();
                return 1;
            }
            catch (Exception ex) { return 0; }
        }


        public async Task<int> UpdateStudentRecordAsync(StudentRecordModel s)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=localhost;Initial Catalog=Students_DB;User Id=sa;password=<password>; Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("Update tbl_Students set name=@Name, age=@Age, Address=@Address where id=@id", con);
                cmd.Parameters.AddWithValue("@id", s.Id);
                cmd.Parameters.AddWithValue("@Name", s.Name);
                cmd.Parameters.AddWithValue("@Age", s.Age);
                cmd.Parameters.AddWithValue("@Address", s.Address);
                await cmd.ExecuteNonQueryAsync();
                con.Close();
                return 1;
            }
            catch (Exception ex) { return 0; }
        }
    }


    public class StudentRecordModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
    }

}